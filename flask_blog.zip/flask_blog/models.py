from datetime import datetime
from extensions import db, login_manager
from flask_login import UserMixin

# association table for posts ↔ tags
post_tags = db.Table(
    'post_tags',
    db.Column('post_id', db.Integer, db.ForeignKey('post.id')),
    db.Column('tag_id', db.Integer, db.ForeignKey('tag.id'))
)

class Subscription(db.Model):
    __tablename__ = 'subscription'
    id = db.Column(db.Integer, primary_key=True)
    subscriber_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    followed_id   = db.Column(db.Integer, db.ForeignKey('user.id'))

class User(UserMixin, db.Model):
    id           = db.Column(db.Integer, primary_key=True)
    username     = db.Column(db.String(64), unique=True, nullable=False)
    email        = db.Column(db.String(120), unique=True, nullable=False)
    password_hash= db.Column(db.String(128), nullable=False)
    posts        = db.relationship('Post', backref='author', lazy='dynamic')
    comments     = db.relationship('Comment', backref='author', lazy='dynamic')
    # подписки
    subscriptions = db.relationship(
        'User', secondary='subscription',
        primaryjoin='Subscription.subscriber_id == User.id',
        secondaryjoin='Subscription.followed_id == User.id',
        backref='subscribers', lazy='dynamic'
    )

class Post(db.Model):
    id         = db.Column(db.Integer, primary_key=True)
    title      = db.Column(db.String(140), nullable=False)
    body       = db.Column(db.Text, nullable=False)
    timestamp  = db.Column(db.DateTime, index=True, default=datetime.utcnow)
    private    = db.Column(db.Boolean, default=False)
    author_id  = db.Column(db.Integer, db.ForeignKey('user.id'))
    tags       = db.relationship('Tag', secondary=post_tags, backref='posts')
    comments   = db.relationship('Comment', backref='post', lazy='dynamic')

class Tag(db.Model):
    id   = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), unique=True, nullable=False)

class Comment(db.Model):
    id         = db.Column(db.Integer, primary_key=True)
    body       = db.Column(db.Text, nullable=False)
    timestamp  = db.Column(db.DateTime, default=datetime.utcnow)
    author_id  = db.Column(db.Integer, db.ForeignKey('user.id'))
    post_id    = db.Column(db.Integer, db.ForeignKey('post.id'))

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))