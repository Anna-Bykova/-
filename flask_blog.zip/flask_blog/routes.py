from flask import (
    Blueprint, render_template, redirect,
    url_for, flash, request, abort
)
from flask_login import (
    login_user, logout_user,
    current_user, login_required
)
from werkzeug.security import generate_password_hash, check_password_hash
from extensions import db
from models import User, Post, Tag, Comment, Subscription
from forms import (
    RegistrationForm, LoginForm,
    PostForm, CommentForm
)

bp = Blueprint('main', __name__)

@bp.route('/')
def index():
    page = request.args.get('page', 1, type=int)
    posts = Post.query.filter_by(private=False) \
        .order_by(Post.timestamp.desc()) \
        .paginate(page=page, per_page=10)
    return render_template('index.html', posts=posts)

@bp.route('/register', methods=['GET','POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    form = RegistrationForm()
    if form.validate_on_submit():
        u = User(
            username=form.username.data,
            email=form.email.data,
            password_hash=generate_password_hash(form.password.data)
        )
        db.session.add(u)
        db.session.commit()
        flash('Registration successful. Please log in.')
        return redirect(url_for('main.login'))
    return render_template('register.html', form=form)

@bp.route('/login', methods=['GET','POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and check_password_hash(user.password_hash, form.password.data):
            login_user(user, remember=form.remember_me.data)
            return redirect(request.args.get('next') or url_for('main.index'))
        flash('Invalid username or password')
    return render_template('login.html', form=form)

@bp.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('main.index'))

@bp.route('/create', methods=['GET','POST'])
@login_required
def create_post():
    form = PostForm()
    if form.validate_on_submit():
        post = Post(
            title=form.title.data,
            body=form.body.data,
            author=current_user,
            private=form.private.data
        )
        tag_names = {t.strip().lower() for t in form.tags.data.split(',') if t.strip()}
        for name in tag_names:
            tag = Tag.query.filter_by(name=name).first()
            if not tag:
                tag = Tag(name=name)
            post.tags.append(tag)
        db.session.add(post)
        db.session.commit()
        flash('Post created.')
        return redirect(url_for('main.index'))
    return render_template('create_post.html', form=form)

@bp.route('/post/<int:post_id>', methods=['GET','POST'])
def view_post(post_id):
    post = Post.query.get_or_404(post_id)
    if post.private and post.author != current_user:
        abort(403)
    form = CommentForm()
    if form.validate_on_submit() and current_user.is_authenticated:
        comment = Comment(body=form.body.data, author=current_user, post=post)
        db.session.add(comment)
        db.session.commit()
        return redirect(url_for('main.view_post', post_id=post_id))
    return render_template('post.html', post=post, form=form)

@bp.route('/post/<int:post_id>/edit', methods=['GET','POST'])
@login_required
def edit_post(post_id):
    post = Post.query.get_or_404(post_id)
    if post.author != current_user:
        abort(403)
    form = PostForm(obj=post)
    if form.validate_on_submit():
        post.title   = form.title.data
        post.body    = form.body.data
        post.private = form.private.data
        post.tags.clear()
        tag_names = {t.strip().lower() for t in form.tags.data.split(',') if t.strip()}
        for name in tag_names:
            tag = Tag.query.filter_by(name=name).first()
            if not tag:
                tag = Tag(name=name)
            post.tags.append(tag)
        db.session.commit()
        flash('Post updated.')
        return redirect(url_for('main.view_post', post_id=post.id))
    form.tags.data = ', '.join([t.name for t in post.tags])
    return render_template('edit_post.html', form=form, post=post)

@bp.route('/post/<int:post_id>/delete', methods=['POST'])
@login_required
def delete_post(post_id):
    post = Post.query.get_or_404(post_id)
    if post.author != current_user:
        abort(403)
    db.session.delete(post)
    db.session.commit()
    flash('Post deleted.')
    return redirect(url_for('main.index'))

@bp.route('/subscribe/<username>')
@login_required
def subscribe(username):
    user = User.query.filter_by(username=username).first_or_404()
    if user == current_user:
        flash("You can't subscribe to yourself.")
    elif current_user.subscriptions.filter_by(id=user.id).first():
        flash('Already subscribed.')
    else:
        current_user.subscriptions.append(user)
        db.session.commit()
        flash(f'Subscribed to {username}.')
    return redirect(url_for('main.profile', username=username))

@bp.route('/unsubscribe/<username>')
@login_required
def unsubscribe(username):
    user = User.query.filter_by(username=username).first_or_404()
    if current_user.subscriptions.filter_by(id=user.id).first():
        current_user.subscriptions.remove(user)
        db.session.commit()
        flash(f'Unsubscribed from {username}.')
    return redirect(url_for('main.profile', username=username))

@bp.route('/feed')
@login_required
def feed():
    followed_ids = [u.id for u in current_user.subscriptions]
    posts = Post.query.filter(
        Post.author_id.in_(followed_ids),
        Post.private == False
    ).order_by(Post.timestamp.desc()).all()
    return render_template('subscriptions.html', posts=posts)

@bp.route('/user/<username>')
def profile(username):
    user = User.query.filter_by(username=username).first_or_404()
    posts = user.posts.filter_by(private=False).order_by(Post.timestamp.desc()).all()
    is_sub = False
    if current_user.is_authenticated:
        is_sub = bool(current_user.subscriptions.filter_by(id=user.id).first())
    return render_template('profile.html', user=user, posts=posts, is_sub=is_sub)

@bp.route('/tag/<string:tag_name>')
def posts_by_tag(tag_name):
    tag = Tag.query.filter_by(name=tag_name).first_or_404()
    posts = tag.posts.filter_by(private=False).order_by(Post.timestamp.desc()).all()
    return render_template('tag.html', tag=tag, posts=posts)