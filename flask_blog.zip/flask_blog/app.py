from flask import Flask
from config import Config
from extensions import db, migrate, login_manager
import models  # ← добавляем, чтобы модели регистрировались перед миграциями/созданием таблиц

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    # инициализация расширений
    db.init_app(app)
    migrate.init_app(app, db)
    login_manager.init_app(app)

    # регистрируем blueprint
    from routes import bp as main_bp
    app.register_blueprint(main_bp)

    return app

if __name__ == '__main__':
    app = create_app()
    # при локальной отладке создаём таблицы автоматом, если их нет
    with app.app_context():
        db.create_all()
    app.run(debug=True)